// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - Game.h file

#ifndef GAME_H
#define GAME_H

#include "Player.h"
#include "Crewmate.h"
#include "Alien.h"
#include "Map.h"
#include "Planet.h"

#include<iostream>

using namespace std;

class Game
{
    public:
        Game();
        Game(int,int);

        int getSizePlayer();
        int getSizeCrewmate();
        int getSizeAlien();
        int getNumPlayers();
        int getNumCrewmates();
        int getNumAliens();
        int getHumansSaved();
        int getHumansPerished();
        int getNumPlanets();

        int readAlienConversation(string filename);
        int readPlanetName(string filename);
        void readQuestions(string filename);
        int readAlienNames(string filename);

        void setHumansSaved(int newHumansSaved);
        void setHumansPerished(int newHumansPerished);
        void setNumPlanets(int getNewNumPlanets);

    private:
        static const int SIZE_PLAYER = 1; 
        static const int SIZE_CREWMATE = 2;
        static const int SIZE_ALIEN = 50;
        static const int SIZE_PLANETS = 50;
        Player player[SIZE_PLAYER];
        Crewmate crewmate[SIZE_CREWMATE];
        Alien alien[SIZE_ALIEN];
        Planet planet[SIZE_PLANETS];

        int numPlayers;
        int numCrewmates;
        int numAliens;
        int humansSaved;
        int humansPerished;
        int numPlanets;
};

#endif
