// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - Crewmate.cpp file

#include "Crewmate.h"

Crewmate::Crewmate()
{
    nameCrewmate = "";
    ability = "";
}

Crewmate::Crewmate(string newNameCrewmate,string newAbility)
{
    nameCrewmate = newNameCrewmate;
    ability = newAbility;
}

string Crewmate::getNameCrewmate()
{
    return nameCrewmate;
}

string Crewmate::getAbility()
{
    return ability;
}

void Crewmate::setNameCrewmate(string newNameCrewmate)
{
    nameCrewmate = newNameCrewmate;
}

void Crewmate::setAbility(string newAbility)
{
    ability = newAbility;
}