// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - Planet.cpp file

#include "Planet.h"

#include<iostream>
#include <fstream>
#include <vector>

using namespace std;

Planet::Planet()
{
    firstString = "";
    secondString = "";
    planetSize = 0;
    fuelForPlanet = 0;
}

Planet::Planet(string newFirstString,string newSecondString,double newPlanetSize,double newFuelForPlanet)
{
    firstString = newFirstString;
    secondString = newSecondString;
    planetSize = newPlanetSize;
    fuelForPlanet = newFuelForPlanet;
}

string Planet::getFirstString()
{
    return firstString;
}

string Planet::getSecondString()
{
    return secondString;
}

double Planet::getPlanetSize()
{
    return planetSize;
}

double Planet::getFueldForPlanet()
{
    return fuelForPlanet;
}

bool Planet::getHability()
{
    return hability;
}

void Planet::setFirstString()
{
    srand(time(0));
    int numOrLetter = 0;
    char letter;
    char num;
    string first = "";
    for(int i = 0;i < 6;i++)
    {
        numOrLetter = (rand() % 2);
        if(numOrLetter == 0)
        {
            letter = (rand() % 26) + 65;
            first += letter;
        }
        else
        {
            num = (rand() % 10) + 48;
            first += num;
        }
    }

    firstString = first;
}

void Planet::setSecondString()
{
    string filename = "four_letter_words.txt";
    int fileSize = 0;

    vector<string> words;
    ifstream myFile;
    myFile.open(filename);
    if(myFile.is_open())
    {
        string line;
        while(getline(myFile,line))
        {
            words.push_back(line);
            fileSize++;
        }

        srand(time(0));
        int rand1 = (rand() % fileSize);

        secondString = words.at(rand1);
    }
    myFile.close();

    return;
}

void Planet::setPlanetSize()
{
    srand(time(0));
    planetSize = (rand() % 8);
}

void Planet::setFuelForPlanet(double newFuelForPlanet)
{
    fuelForPlanet = newFuelForPlanet;
}

void Planet::setHability(bool newHability)
{
    hability = newHability;
}

double Planet::getNewPlanetCapac()
{
    return planetCapac;
}

void Planet::setPlanetCapac()
{
    planetCapac = planetSize * 615;
}
