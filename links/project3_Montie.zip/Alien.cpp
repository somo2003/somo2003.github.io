// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - Alien.cpp file

#include<iostream>
#include<fstream>
#include "Alien.h"

using namespace std;

Alien::Alien()
{
    nameAlien = "";
    hostility = 0;
}

Alien::Alien(string newNameAlien,bool newHostility)
{
    nameAlien = newNameAlien;
    hostility = newHostility;
}

string Alien::getNameAlien()
{
    return nameAlien;
}

bool Alien::getHostility()
{
    return hostility;
}

void Alien::setNameAlien(string newNameAlien)
{
    nameAlien = newNameAlien;
}

void Alien::setHostility(bool newHostility)
{
    hostility = newHostility;
}

void Alien::readAlienNames()
{
    string alienNames[20];
    int index = 0;
    int i = 0;

    ifstream myFile;
    myFile.open("alien_names.txt");
    if(myFile.is_open())
    {
        string line;
        while(getline(myFile,line))
        {
            alienNames[i] = line;
        }

        srand(time(0));
        index = (rand() / 10);
        nameAlien = alienNames[index];

    }
    myFile.close();
}