// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - Crewmate.h file

#ifndef CREWMATE_H
#define CREWMATE_H

#include<iostream>

using namespace std;

class Crewmate
{
    public:
        Crewmate();
        Crewmate(string,string);

        string getNameCrewmate();
        string getAbility();

        void setNameCrewmate(string newNameCrewmate);
        void setAbility(string newAbility);

    private:
        string nameCrewmate;
        string ability;
};

#endif