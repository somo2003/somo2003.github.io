// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - Player.cpp file

#include "Player.h"
#include <fstream>
#include<iostream>
#include<vector>

using namespace std;

// Split function
int split(string inputString, char separator,string arr[],int size)
{
    int count = 0;
    int arrCount = 0;
    string empty = "";
    string word = "";
    bool check = true;
    if(inputString == "")
    {
        count = 0;
    }
    while (size > 0)
    {
        for (int i = 0; i < inputString.length() && check == true; i++)
        {
            char separatorChar = inputString[i];
            if (separatorChar == separator)
            {
                if(word.length() != 0)
                {
                    arr[arrCount] = word; 
                    count++;
                    arrCount++;
                }
                word = "";
                if (count == size)
                {
                    check = false;
                }
            }
            if(separatorChar != separator)
            {
                word = word + inputString[i];
            }
            if(i == inputString.length() - 1)
            {
                arr[arrCount] = word;
                count++;
                arrCount++;
            }
        }
        if(inputString == empty)
        {
            return 0;
        }
        if(check == false)
        {
            return -1;
        }
        if(arrCount == 0)
        {
            arr[arrCount] = inputString;
            return 1;
        }
        size--;
        break;
    }

    return count;

}

Player::Player()
{
    namePlayer = "";
    money = 100000;
    spaceSuit = 1;
    spaceSuitHealth = 100;
    weapon.push_back("Light saber");
    health = 100;
    medicalKit = 0;
    fuel = 200000;
    translator = false;
    weaponNum = 1;
    
    for(int i = 0; i < CREW_SIZE; i++)
    {
        crewmates[i] = "";
    }

    for(int i = 1; i < WEAPON_SIZE; i++)
    {
        weapon.push_back("");
    }
}

Player::Player(string newNamePlayer,string newCrewmates[CREW_SIZE],int newMoney,int newSpaceSuit,int newHealth, int newFuel, bool newTranslator,int newWeaponNum, vector<string> newWeapon,int newSpaceSuitHealth)
{
    namePlayer = newNamePlayer;
    money = newMoney;
    spaceSuit = newSpaceSuit;
    spaceSuitHealth = newSpaceSuitHealth;
    health = newHealth;
    fuel = newFuel;
    translator = newTranslator;
    weaponNum = newWeaponNum;

    for(int i = 0; i < CREW_SIZE; i++)
    {
        crewmates[i] = newCrewmates[i];
    }

    for(int i = 0; i < WEAPON_SIZE; i++)
    {
        weapon.at(i) = newWeapon.at(i);
    }
}

string Player::getNamePlayer()
{
    return namePlayer;
}

string Player::getCrewmates(int index)
{
    if(index >= CREW_SIZE || index < 0)
    {
        return "";
    }

    return crewmates[index];
}

int Player::getCrewSize()
{
    return CREW_SIZE;
}

int Player::getMoney()
{
    return money;
}

int Player::getSpaceSuit()
{
    return spaceSuit;
}

int Player::getWeaponSize()
{
    return WEAPON_SIZE;
}

string Player::getWeapon(int index)
{
    if(index >= weaponNum || index < 0)
    {
        return "";
    }

    return weapon.at(index);
}

int Player::getHealth()
{
    return health;
}

int Player::getFuel()
{
    return fuel;
}

bool Player::getTranslator()
{
    return translator;
}

int Player::getWeaponNum()
{
    return weaponNum;
}

void Player::setNamePlayer(string newNamePlayer)
{
    namePlayer = newNamePlayer;
}

void Player::chooseCrewmates(string newCrewmate,int index)
{
    crewmates[index] = newCrewmate;
}

void Player::readCrewmatesFile(string filename)
{
    int count = 1;
    string arr[2];

    cout << endl;
    cout << "Pick a crewmate to help you with your journey!" << endl;
    cout << endl;

    ifstream myFile;
    char enter;
    myFile.open(filename);
    if(myFile.is_open())
    {
        string line;
        while(getline(myFile,line))
        {
            split(line,';',arr,2);
            cout << count << ". "; 
            cout << arr[0] << endl;
            cout << "Ability: " << arr[1] << endl;

            count++;
        }
    }
    myFile.close();
}

void Player::setMoney(int newMoney)
{
    money = newMoney;
}

void Player::setSpaceSuit(int newSpaceSuit)
{
    spaceSuit = newSpaceSuit;
}

void Player::setWeapon(string newWeapon)
{
    weapon.push_back(newWeapon);
    // weaponNum++;
}

void Player::eraseWeapon(int index)
{
    weapon.erase(weapon.begin() + index);
    weaponNum--;
}

void Player::setHealth(int newHealth)
{
    health = newHealth;
}

void Player::setMedicalKit(int newMedicalKit)
{
    medicalKit = newMedicalKit;
}

void Player::setFuel(int newFuel)
{
    fuel = newFuel;
}

void Player::setTranslator(bool newTranslator)
{
    translator = newTranslator;
}

void Player::setWeaponNum(int newWeaponNum)
{
    weaponNum = newWeaponNum;
}

int Player::getMedicalKit()
{
    return medicalKit;
}

int Player::getSpaceSuitHealth()
{
    return spaceSuitHealth;
}

void Player::setSpaceSuitHealth(int newSpaceSuitHealth)
{
    spaceSuitHealth = newSpaceSuitHealth;
}