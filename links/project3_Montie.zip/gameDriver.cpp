// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - gameDriver.cpp file

// fix planet (1002)

#include<cassert>
#include<fstream>
#include<iomanip>
#include<iostream>
#include<string>

#include "Player.h"
#include "Crewmate.h"
#include "Alien.h"
#include "Map.h"
#include "Planet.h"
#include "Game.h"

using namespace std;

Player player;
Map map;
Alien alien;
Planet planet;
Game game;

int planetNum = 1;
int planetsGuessed = 0;
int habitablePlanets = 0;
string habitableTraits = "";
string unhabitableTraits = "";

void resourceCenter();
void weaponGoBack();
void alienBattle();
void mainMenu();
void mapChoice();
void viewStatus();
void viewLogBook();
void enterWormhole();
void reportPlanet();

// Log Book
void logBook()
{
    ofstream myFile;
    myFile.open("logBook.txt");
    if(myFile.is_open())
    {
        myFile << player.getNamePlayer() << "'s Log Book page #" << planetNum << ": Planet " << planet.getFirstString() << "-" << planet.getSecondString() << endl;
        myFile << "Planet size (in diameter of 1000 kms): " << planet.getPlanetSize() << endl;
        myFile << "Planet’s carrying capacity (in millions): " << planet.getNewPlanetCapac() << endl;
        myFile << "Habitable traits discovered: " << habitableTraits << endl;
        myFile << "Non-habitable traits discovered: " << unhabitableTraits << endl;
        myFile << "Friendly alien assessment: None" << endl;
    }

    cout << player.getNamePlayer() << "'s Log Book page #" << planetNum << ": Planet " << planet.getFirstString() << "-" << planet.getSecondString() << endl;
    cout << "Planet size (in diameter of 1000 kms): " << planet.getPlanetSize() << endl;
    cout << "Planet’s carrying capacity (in millions): " << planet.getNewPlanetCapac() << endl;
    cout << "Habitable traits discovered: None" << endl;
    cout << "Non-habitable traits discovered: None" << endl;
    cout << "Friendly alien assessment: None" << endl;

    return;
}

// New planet
void newPlanet()
{
    planet.setPlanetSize();
    planet.setPlanetCapac();
    planet.setFirstString();
    planet.setSecondString();
}

// Buy a weapon
void weapon()
{
    int quantity;
    int type = 0;
    cout << "Which weapon type do you wish to buy?\n1. Light Saber\n2. Blaster\n3. Beam Gun\n4. Go back to menu" << endl;
    cin >> type;
    if(type != 1 && type != 2 && type != 3 && type != 4)
    {
        cout << "Re-enter a valid option." << endl;
    }
    else if(type == 1)
    {
        cout << "How many Light Sabers would you like ($1,000 each)?" << endl;
        cin >> quantity;
                
        if(quantity < 0)
        {
            cout << "Re-enter a valid quantity." << endl;
            cin >> quantity;
        }
            else if(quantity >= 2 || player.getWeaponNum() == 2)
            {
                cout << "You cannot have more than two weapons at the same time, re-enter a valid quantity." << endl;
                cin >> quantity;
            }
            else if(player.getMoney() <= quantity * 1000)
            {
                cout << "You do not have enough money for that. Which weapon type do you wish to buy?" << endl;
                weapon();
            }
            else
            {
                player.setMoney(player.getMoney() - (quantity * 1000));
                player.setWeapon("Light saber");
                player.setWeaponNum(player.getWeaponNum() + 1);
                cout << "You have $" << player.getMoney() << " left." << endl;
                weapon();
            }  
    }
    else if(type == 2)
    {
        cout << "How many Blasters would you like ($2,000 each)?" << endl;
        cin >> quantity;
        
        if(quantity < 0)
        {
            cout << "Re-enter a valid quantity." << endl;
            cin >> quantity;
        }
        else if(quantity >= 2 || player.getWeaponNum() == 2)
        {
            cout << "You cannot have more than two weapons at the same time, re-enter a valid quantity." << endl;
            cin >> quantity;
        }
        else if(player.getMoney() <= quantity * 2000)
        {
            cout << "You do not have enough money for that. Which weapon type do you wish to buy?" << endl;
            weapon();
        }
        else
        {
            player.setMoney(player.getMoney() - (quantity * 2000));
            cout << "You have $" << player.getMoney() << " left." << endl;
            player.setWeapon("Blaster");
            player.setWeaponNum(player.getWeaponNum() + 1);
            weapon();
        }
    }
    else if(type == 3)
    {
        cout << "How many Beam Guns would you like ($5,000 each)?" << endl;
        cin >> quantity;
        
        if(quantity < 0)
        {
            cout << "Re-enter a valid quantity." << endl;
            cin >> quantity;
        }
        else if(quantity >= 2 || player.getWeaponNum() == 2)
        {
            cout << "You cannot have more than two weapons at the same time, re-enter a valid quantity." << endl;
            cin >> quantity;
        }
        else if(player.getMoney() <= quantity * 5000)
        {
            cout << "You do not have enough money for that. Which weapon type do you wish to buy?" << endl;
            weapon();
        }
        else
        {
            player.setMoney(player.getMoney() - (quantity * 5000));
            cout << "You have $" << player.getMoney() << " left." << endl;
            player.setWeapon("Beam gun");
            player.setWeaponNum(player.getWeaponNum() + 1);
            weapon();
        }
    }
    else if(type == 4)
    {
        return;
    }
    
}

// Buy a weapon no menu
void weaponGoBack()
{
    int quantity;
    int type = 0;
    cout << "Which weapon type do you wish to buy?\n1. Light Saber\n2. Blaster\n3. Beam Gun" << endl;
    cin >> type;
    if(type != 1 && type != 2 && type != 3)
    {
        cout << "Re-enter a valid option." << endl;
    }
    else if(type == 1)
    {
        cout << "How many Light Sabers would you like ($1,000 each)?" << endl;
        cin >> quantity;
                
        if(quantity < 0)
        {
            cout << "Re-enter a valid quantity." << endl;
            cin >> quantity;
        }
            else if(quantity > player.getWeaponNum())
            {
                cout << "You cannot have more than two weapons at the same time, re-enter a valid quantity." << endl;
                cin >> quantity;
            }
            else if(player.getMoney() <= quantity * 1000)
            {
                cout << "You do not have enough money for that. Which weapon type do you wish to buy?" << endl;
                cout << "1. Light Saber\n2. Blaster\n3. Beam Gun" << endl;
                cin >> type;
            }
            else
            {
                player.setMoney(player.getMoney() - (quantity * 1000));
                cout << "You have $" << player.getMoney() << " left." << endl;
                cout << "Which weapon type do you wish to buy?\n1. Light Saber\n2. Blaster\n3. Beam Gun" << endl;
                cin >> type;
            }  
    }
    else if(type == 2)
    {
        cout << "How many Blasters would you like ($2,000 each)?" << endl;
        cin >> quantity;
        
        if(quantity < 0)
        {
            cout << "Re-enter a valid quantity." << endl;
            cin >> quantity;
        }
        else if(quantity > player.getWeaponNum())
        {
            cout << "You cannot have more than two weapons at the same time, re-enter a valid quantity." << endl;
            cin >> quantity;
        }
        else if(player.getMoney() <= quantity * 2000)
        {
            cout << "You do not have enough money for that. Which weapon type do you wish to buy?" << endl;
            cout << "1. Light Saber\n2. Blaster\n3. Beam Gun" << endl;
            cin >> type;
        }
        else
        {
            player.setMoney(player.getMoney() - (quantity * 2000));
            cout << "You have $" << player.getMoney() << " left." << endl;
            cout << "Which weapon type do you wish to buy?\n1. Light Saber\n2. Blaster\n3. Beam Gun" << endl;
            cin >> type;
        }
    }
    else if(type == 3)
    {
        cout << "How many Beam Guns would you like ($5,000 each)?" << endl;
        cin >> quantity;
        
        if(quantity < 0)
        {
            cout << "Re-enter a valid quantity." << endl;
            cin >> quantity;
        }
        else if(quantity > player.getWeaponNum())
        {
            cout << "You cannot have more than two weapons at the same time, re-enter a valid quantity." << endl;
            cin >> quantity;
        }
        else if(player.getMoney() <= quantity * 5000)
        {
            cout << "You do not have enough money for that. Which weapon type do you wish to buy?" << endl;
            cout << "1. Light Saber\n2. Blaster\n3. Beam Gun" << endl;
            cin >> type;
        }
        else
        {
            player.setMoney(player.getMoney() - (quantity * 5000));
            cout << "You have $" << player.getMoney() << " left." << endl;
            cout << "Which weapon type do you wish to buy?\n1. Light Saber\n2. Blaster\n3. Beam Gun" << endl;
            cin >> type;
        }
    }

    alienBattle();
}

// Buy a translator
void translator()
{
    int choice = 0;
    cout << "Would you like to purchase a translator device ($5,000)? 1 for yes, 0 for no." << endl;
    cin >> choice;
    if(choice != 0 && choice != 1)
    {
        cout << "Please enter a valid input." << endl;
        cin >> choice;
    }
    else if(choice == 1)
    {
        player.setTranslator(true);
        player.setMoney(player.getMoney() - 5000);
        cout << "You have $" << player.getMoney() << " left." << endl;
        return;
    }
    else if(choice == 0)
    {
        return;
    }
    return;
}

// Buy a Space Suit
void spacceSuit()
{
    int grade = 0;
    if(player.getSpaceSuit() == 1)
    {
        cout << "Would you like to upgrade your spacesuit to any of these? The space suit health will be set to 100%.\n1. Space suit grade 2 is $5,000\n2. Space suit grade 3 is $10,000\n3. Space suit grade 4 is $15,000\n4. Space suit grade 5 is $20,000\n5. Return to menu." << endl;
        cin >> grade;
        if(grade < 1 || grade > 4)
        {
            cout << "Re-enter a valid option." << endl;
            cin >> grade;
        }
        else if(grade == 1)
        {
            if(player.getMoney() > 5000)
            {
                player.setSpaceSuit(2);
                cout << "Your spacesuit is now a grade 2." << endl;
                cout << "You have $" << player.getMoney() - 5000 << " left." << endl;

                return;
            }
            else
            {
                cout << "You do not have enough money for that. Which space suit type do you wish to buy?" << endl;
                cout << "1. Grade 1\n2. Grade 2\n3. Grade 3\n4. Grade 4\n5. Go back to menu." << endl;
                cin >> grade;
            }
        }
        else if(grade == 2)
        {
            if(player.getMoney() > 10000)
            {
                player.setSpaceSuit(3);
                cout << "Your spacesuit is now a grade 3." << endl;
                cout << "You have $" << player.getMoney() - 10000 << " left." << endl;

                return;
            }
            else
            {
                cout << "You do not have enough money for that. Which space suit type do you wish to buy?" << endl;
                cout << "1. Grade 1\n2. Grade 2\n3. Grade 3\n4. Grade 4\n5. Go back to menu." << endl;
                cin >> grade;
            }
        }
        else if(grade == 3)
        {
            if(player.getMoney() > 15000)
            {
                player.setSpaceSuit(4);
                cout << "Your spacesuit is now a grade 4." << endl;
                cout << "You have $" << player.getMoney() - 15000 << " left." << endl;

                return;
            }
            else
            {
                cout << "You do not have enough money for that. Which space suit type do you wish to buy?" << endl;
                cout << "1. Grade 1\n2. Grade 2\n3. Grade 3\n4. Grade 4\n5. Go back to menu." << endl;
                cin >> grade;
            }
        }
        else if(grade == 4)
        {
            if(player.getMoney() > 20000)
            {
                player.setSpaceSuit(5);
                cout << "Your spacesuit is now a grade 5." << endl;
                cout << "You have $" << player.getMoney() - 20000 << " left." << endl;

                return;
            }
            else
            {
                cout << "You do not have enough money for that. Which space suit type do you wish to buy?" << endl;
                cout << "1. Grade 1\n2. Grade 2\n3. Grade 3\n4. Grade 4\n5. Go back to menu." << endl;
                cin >> grade;
            }
        }
        else if(grade == 5)
        {
            return;
        }

    }
    if(player.getSpaceSuit() == 2)
    {
        cout << "Would you like to upgrade your spacesuit to any of these? The space suit health will be set to 100%.\n1. Space suit grade 3 is $5,000\n2. Space suit grade 4 is $10,000\n3. Space suit grade 5 is $15,000" << endl;
        cin >> grade;
        if(grade < 1 || grade > 3)
        {
            cout << "Re-enter a valid option." << endl;
            cin >> grade;
        }
        else if(grade == 1)
        {
            if(player.getMoney() > 5000)
            {
                player.setSpaceSuit(3);
                cout << "Your spacesuit is now a grade 3." << endl;
                cout << "You have $" << player.getMoney() - 5000 << " left." << endl;
            }
            else
            {
                cout << "You do not have enough money for that. Which space suit type do you wish to buy?" << endl;
                cout << "1. Grade 1\n2. Grade 2\n3. Grade 3\n4. Grade 4\n5. Go back to menu." << endl;
                cin >> grade;
            }
        }
        else if(grade == 2)
        {
            if(player.getMoney() > 10000)
            {
                player.setSpaceSuit(4);
                cout << "Your spacesuit is now a grade 4." << endl;
                cout << "You have $" << player.getMoney() - 10000 << " left." << endl;
            }
            else
            {
                cout << "You do not have enough money for that. Which space suit type do you wish to buy?" << endl;
                cout << "1. Grade 1\n2. Grade 2\n3. Grade 3\n4. Grade 4\n5. Go back to menu." << endl;
                cin >> grade;
            }
        }
        else if(grade == 3)
        {
            if(player.getMoney() > 15000)
            {
                player.setSpaceSuit(5);
                cout << "Your spacesuit is now a grade 5." << endl;
                cout << "You have $" << player.getMoney() - 15000 << " left." << endl;
            }
            else
            {
                cout << "You do not have enough money for that. Which space suit type do you wish to buy?" << endl;
                cout << "1. Grade 1\n2. Grade 2\n3. Grade 3\n4. Grade 4\n5. Go back to menu." << endl;
                cin >> grade;
            }
        }

            return;
    }
    if(player.getSpaceSuit() == 3)
    {
        cout << "Would you like to upgrade your spacesuit to any of these? The space suit health will be set to 100%.\n1. Space suit grade 4 is $5,000\n2. Space suit grade 5 is $10,000" << endl;
        cin >> grade;
        if(grade < 1 || grade > 2)
        {
            cout << "Re-enter a valid option." << endl;
            cin >> grade;
        }
        else if(grade == 1)
        {
            if(player.getMoney() > 5000)
            {
                player.setSpaceSuit(4);
                cout << "Your spacesuit is now a grade 4." << endl;
                cout << "You have $" << player.getMoney() - 5000 << " left." << endl;
            }
            else
            {
                cout << "You do not have enough money for that. Which space suit type do you wish to buy?" << endl;
                cout << "1. Grade 1\n2. Grade 2\n3. Grade 3\n4. Grade 4\n5. Go back to menu." << endl;
                cin >> grade;
            }
        }
        else if(grade == 2)
        {
            if(player.getMoney() > 10000)
            {
                player.setSpaceSuit(5);
                cout << "Your spacesuit is now a grade 5." << endl;
                cout << "You have $" << player.getMoney() - 10000 << " left." << endl;
            }
            else
            {
                cout << "You do not have enough money for that. Which space suit type do you wish to buy?" << endl;
                cout << "1. Grade 1\n2. Grade 2\n3. Grade 3\n4. Grade 4\n5. Go back to menu." << endl;
                cin >> grade;
            }
        }

            return;
    }
    if(player.getSpaceSuit() == 4)
    {
        cout << "Would you like to upgrade your spacesuit to any of these? The space suit health will be set to 100%.\n1. Space suit grade 5 is $5,000" << endl;
        cin >> grade;
        if(grade < 1 || grade > 1)
        {
            cout << "Re-enter a valid option." << endl;
            cin >> grade;
        }
        else if(grade == 1)
        {
            if(player.getMoney() > 5000)
            {
                player.setSpaceSuit(5);
                cout << "Your spacesuit is now a grade 5." << endl;
                cout << "You have $" << player.getMoney() - 5000 << " left." << endl;
            }
            else
            {
                cout << "You do not have enough money for that. Which space suit type do you wish to buy?" << endl;
                cout << "1. Grade 1\n2. Grade 2\n3. Grade 3\n4. Grade 4\n5. Go back to menu." << endl;
                cin >> grade;
            }
        }

         return;
    }

}

// Buy a Medical Kit
void medicalKit()
{
    int num = 0;

    cout << "How many medical kits would you like to purchase ($2,000 each)? You currently have 0, and can at most have 5." << endl;
    cin >> num;

    if((player.getMedicalKit() + num) >= 5)
    {
        cout << "You cannot have more than 5 kits. Re-enter a valid quantity." << endl;
        cin >> num;
    }
    if(num < 0)
    {
        cout << "Re-enter a valid quantity." << endl;
        cin >> num;
    }
    else
    {
        player.setMoney(player.getMoney() - (num * 2000));
        cout << "You have $" << player.getMoney() << " left." << endl;
        return;
    }

    return;
}

// Buy Fuel
void fuel()
{
    if(player.getFuel() >= 400000)
    {
        cout << "The fuel tank is already at capacity! So you cannot buy more." << endl;
        return;
    }

    int num = 0;
    
    cout << "You have " << player.getFuel() << " gallons of fuel. Your spacecraft can hold " << (400000 - player.getFuel()) / 1000 << "k gallons of fuel. How many gallons would you like to purchase ($1,000 per 10,000 gallons)? Input must be in multiples of 10000s. " << endl;
    cin >> num;

    if(num % 10000)
    {
        cout << "Input must be in multiples of 10000s. Re-enter a valid quantity." << endl;
        cin >> num;
    }
    if((player.getFuel() + (num * 10)) > 400000)
    {
        cout << "You cannot buy more fuel than the fuel tank's capacity, which is 400K." << endl;
        cin >> num;
    }
    else
    {
        player.setFuel(player.getFuel() + num);
        num = num / 10000;
        player.setMoney(player.getMoney() - (num * 1000));
        cout << "You have $" << player.getMoney() << " left." << endl;
        return;
    }
}

// Resource Center menu
void resourceCenter()
{
    int num = 0;

    cout << "Which item do you wish to buy?" << endl;
    cout << "1. Weapon\n2. Translator\n3. Space Suit\n4. Medical Kits\n5. Fuel\n6. Purchase and Leave" << endl;
    cin >> num;

    if(num == 6)
    {
        return;
    }
    
    if(num < 1 || num > 6)
    {
        cout << "Re-enter a valid option." << endl;
        cin >> num;
    }
    if(num == 1)
    {
        weapon();
        resourceCenter();
    }
    if(num == 2)
    {
        translator();
        resourceCenter();
    }
    if(num == 3)
    {
        spacceSuit();
        resourceCenter();
    }
    if(num == 4)
    {
        medicalKit();
        resourceCenter();
    }
    if(num ==5)
    {
        fuel();
        resourceCenter();
    }
    if(num == 6)
    {
        // purchase
        return;
    }
    
}

// Choose crewmates
void chooseCrewmates()
{
    int num = 0;

    player.readCrewmatesFile("crewmates.txt");

    cin >> num;

    if(num < 1 || num > 4)
    {
        cout << "Re-enter a valid input." << endl;
        cin >> num;
    }
    if(num == 1)
    {
        player.chooseCrewmates("Lola",0);
        cout << endl;
        cout << "Great choice! " << "Lola" << " will bring a lot to your team. Pick your last crewmate." << endl;
        cout << endl;
        cout << "2. Nerys Fighter\nAbility: Nerys is a world-class warrior and weapons operator, increase your odds of winning a battle with hostile aliens by 10%." << endl;
        cout << "3. Millie Tycoon\nAbility: Millie is an fuel tycoon and will allow you to start with double the fuel." << endl;
        cout << "4. Chuck Intimidator\nAbility: Chuck was once part of the CIA and is very charismatic and intimidating, the friendly alien will be 10% more likely to tell the truth." << endl;
        cin >> num;
        if(num < 2 || num > 4)
        {
            cout << "Re-enter a valid input." << endl;
            cin >> num;
        }
        if(num == 2)
        {
            player.chooseCrewmates("Nerys",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }
        else if(num == 3)
        {
            player.chooseCrewmates("Millie",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }
        else
        {
            player.chooseCrewmates("Chuck",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }
    }
    else if(num == 2)
    {
        player.chooseCrewmates("Nerys",0);
        cout << "Great choice! " << "Nerys" << " will bring a lot to your team. Pick your last crewmate." << endl;
        cout << "1. Lola Doctor\nAbility: Lola is a very successful healer and doctor and will make you gain 5% health each time you lose health after a battle." << endl;
        cout << "3. Millie Tycoon\nAbility: Millie is an fuel tycoon and will allow you to start with double the fuel." << endl;
        cout << "4. Chuck Intimidator\nAbility: Chuck was once part of the CIA and is very charismatic and intimidating, the friendly alien will be 10% more likely to tell the truth." << endl;
        cin >> num;
        if(num != 1 && num != 3 && num != 4)
        {
            cout << "Re-enter a valid input." << endl;
            cin >> num;
        }
        if(num == 1)
        {
            player.chooseCrewmates("Lola",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }
        else if(num == 3)
        {
            player.chooseCrewmates("Millie",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }
        else
        {
            player.chooseCrewmates("Chuck",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }

    }
    else if(num == 3)
    {
        player.chooseCrewmates("Millie",0);
        cout << "Great choice! " << "Millie" << " will bring a lot to your team. Pick your last crewmate." << endl;
        cout << "1. Lola Doctor\nAbility: Lola is a very successful healer and doctor and will make you gain 5% health each time you lose health after a battle." << endl;
        cout << "2. Nerys Fighter\nAbility: Nerys is a world-class warrior and weapons operator, increase your odds of winning a battle with hostile aliens by 10%." << endl;
        cout << "4. Chuck Intimidator\nAbility: Chuck was once part of the CIA and is very charismatic and intimidating, the friendly alien will be 10% more likely to tell the truth." << endl;
        cin >> num;
        if(num != 1 && num != 2 && num != 4)
        {
            cout << "Re-enter a valid input." << endl;
            cin >> num;
        }
        if(num == 1)
        {
            player.chooseCrewmates("Lola",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }
        else if(num == 2)
        {
            player.chooseCrewmates("Nerys",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }
        else
        {
            player.chooseCrewmates("Chuck",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }
    }
    else
    {
        player.chooseCrewmates("Chuck",0);
        cout << "Great choice! " << "Chuck" << " will bring a lot to your team. Pick your last crewmate." << endl;
        cout << "1. Lola Doctor\nAbility: Lola is a very successful healer and doctor and will make you gain 5% health each time you lose health after a battle." << endl;
        cout << "2. Nerys Fighter\nAbility: Nerys is a world-class warrior and weapons operator, increase your odds of winning a battle with hostile aliens by 10%." << endl;
        cout << "3. Millie Tycoon\nAbility: Millie is an fuel tycoon and will allow you to start with double the fuel." << endl;
        cin >> num;
        if(num != 1 && num != 2 && num != 3)
        {
            cout << "Re-enter a valid input." << endl;
            cin >> num;
        }
        if(num == 1)
        {
            player.chooseCrewmates("Lola",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }
        else if(num == 2)
        {
            player.chooseCrewmates("Nerys",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }
        else
        {
            player.chooseCrewmates("Millie",1);
            cout << "You have a very impressive crew. With your leadership, you will be sure to succeed." << endl;
            return;
        }

    }    
}

// Alien battle
void alienBattle()
{
    // fight
    int num = 0;
    cout << "Let’s attack! Choose a weapon from your arsenal quickly and attack before the enemy advances!" << endl;
    for(int i = 0; i < player.getWeaponNum(); i++)
    {   
        // weaponName = player.getWeapon(i);
        cout << i << ". " << player.getWeapon(i) << endl;
    }
    cin >> num;
    if(num < 0 || num > player.getWeaponNum())
    {
        cout << "Re-enter valid input." << endl;
        cin >> num;
    }
    else
    {
        string weapon = player.getWeapon(num);
        int weaponType = 0;
        int r1 = (rand() / 6);
        int r2 = (rand() / 6);
        int fighter = 0;
        if(player.getCrewSize() > 1)
        {
            fighter = 1;
        }
        int chances = (r1 * weaponType)*(1 + fighter) - (r2 * planetNum);
        if(chances > 0 && player.getWeaponNum() < 2)
        {
            player.setSpaceSuitHealth(player.getSpaceSuitHealth() - (player.getSpaceSuitHealth() * .1));
            cout << "You defeated " << alien.getNameAlien() << "! Great Job! You won Beam gun. But you lost 10% of space suit health while fighting." << endl;
            mainMenu();
        }
        else if(chances > 0)
        {
            player.setSpaceSuitHealth(player.getSpaceSuitHealth() - (player.getSpaceSuitHealth() * .1));
            cout << "You defeated " << alien.getNameAlien() << "! Great Job! You saw the enemy's weapon lying down but you cannot carry with you as you already have 2 weapons. Unfortunately, you lost 10% of space suit health while fighting." << endl;
            mainMenu();
        }
        else
        {
            cout << "Aggh! You lost the battle! " << alien.getNameAlien() << " seems to be hard for you! Tough times. Unfortunately, you experience the following due to this loss:" << endl;
            cout << "1. Your health was decreased by 30%." << endl;
            player.setHealth(player.getHealth() - (player.getHealth()*.3));
            cout << "2. Your suit health decreased by 40%." << endl;
            player.setSpaceSuitHealth(player.getSpaceSuitHealth() - (player.getSpaceSuitHealth() * .4));
            cout << "3. You lost " << weapon <<", the weapon you used for attacking the alien. " << endl;
            player.eraseWeapon(num);
            mainMenu();
        }
    }
}

// Site
void site()
{
    char letter;
    game.readQuestions("questions.txt");
    cin >> letter;

    if(letter != 'a' && letter != 'b' && letter != 'c' && letter != 'd')
    {
        cout << "Re-enter a valid input." << endl;
        cin >> letter;
    }
    if(letter == 'a')
    {
        cout << "Correct answer!" << endl;
        string trait = "";
        if(map.getSiteTrait() == 1)
        {
            trait = "water";
            habitableTraits += trait + ",";
        }
        else if(map.getSiteTrait() == 2)
        {
            trait = "oxygen";
            habitableTraits += trait + ",";
        }
        else if(map.getSiteTrait() == 3)
        {
            trait = "fertile soil";
            habitableTraits += trait + ",";
        }
        else if(map.getSiteTrait() == 4)
        {
            trait = "bad atmosphere";
             unhabitableTraits += trait + ",";
        }
        else if(map.getSiteTrait() == 5)
        {
            trait = "toxic gas";
            unhabitableTraits += trait + ",";
        }
        else if(map.getSiteTrait() == 6)
        {
            trait = "extreme temperatures";
            unhabitableTraits += trait + ",";
        }
        cout << "You just discovered that this planet has " << trait << ". This is a great sign. This discovery has been added to your log book." << endl;
        return;
    }
    else if(letter == 'b' || letter == 'c' || letter == 'd')
    {
        cout << "Incorrect answer! Reduced your health by 1% because of frustration." << endl;
        player.setHealth(player.getHealth() - (player.getHealth() * .01));
        return;
    }
}

// Map
void mapChoice()
{
    map.displayMap();

    char move;

    cout << "Select one: w. up s. down d. right a. left m. menu" << endl;
    cin >> move;

    while(move != 'm')
    {
        map.executeMove(move);
        map.displayMap();
        cout << "Select one: w. up s. down d. right a. left m. menu" << endl;
        cin >> move;
        if(map.isMisfortuneLocaton())
        {
            map.revealMisfortune(map.getPlayerRowPosition(),map.getPlayerColPosition());
            if(map.getMisfortuneType() == 1)
            {
                // alien attack
                string alienName = alien.getNameAlien();
                char choice;

                cout << "You just ran into " << alienName << "! Think you can beat this dangerous alien for helping save humanity?" << endl;
                cout << "Would you like to attack (a) or forfeit (f)?" << endl;
                cin >> choice;

                if(choice != 'a' && choice != 'f')
                {
                    cout << "Re-enter a valid input." << endl;
                    cin >> choice;
                }
                else if(choice == 'f' && player.getWeaponNum() > 0)
                {
                    cout << "Really?! You chose to forfeit the battle? This is disappointing! You lost a weapon due to this decision. Hopefully, you git gud before you encounter the next alien." << endl;
                    player.eraseWeapon((rand() / 2));
                    mapChoice();
                }
                else if(choice == 'f' && player.getWeaponNum() == 0)
                {
                    cout << "Really?! You chose to forfeit the battle? This is disappointing! Since you do not have a weapon, you just lost a huge chunk of money from your account. Hopefully, you git gud before you encounter the next alien." << endl;
                    if(player.getMoney() >= 10000)
                    {
                        player.setMoney(player.getMoney() - 10000);
                    }
                    else
                    {
                        player.setMoney(0);
                    }
                    mapChoice();
                }
                else if(choice == 'a')
                {
                    if(player.getWeaponNum() == 0 && player.getMoney() <= 1000)
                    {
                        mainMenu();
                        // print out that line
                    }
                    else if(player.getWeaponNum() == 0)
                    {
                        cout << "You do not have a weapon to fight! Lets visit the resource center and buy a weapon!" << endl;
                        weaponGoBack();
                    }
                }
            }
            else if(map.getMisfortuneType() == 2)
            {
                // extreme weather event
                player.setHealth(player.getHealth() - (player.getHealth() * .1));
                player.setSpaceSuitHealth(player.getSpaceSuitHealth() - ((.5 - (.1 * player.getSpaceSuit())) * player.getSpaceSuitHealth()));
                cout << "Oh no! You have encountered extreme weather. Your health decreased by 10%." << endl;
                if(player.getHealth() == 0)
                {
                    return;
                }
                else
                {
                    cout << "Select one: w. up s. down d. right a. left m. menu" << endl;
                    cin >> move;
                }
            }
            else if(map.getMisfortuneType() == 3)
            {
                // fall into a crater
                player.setHealth(player.getHealth() - (player.getHealth() * .5));
                player.setSpaceSuitHealth(player.getSpaceSuitHealth() - ((.5 - (.1 * player.getSpaceSuit())) * player.getSpaceSuitHealth()));
                // reveal and 'o'
                cout << "Oh no! You have encountered a crater. Your health decreased by 50%." << endl;
                if(player.getHealth() == 0)
                {
                    return;
                }
                else
                {
                    cout << "Select one: w. up s. down d. right a. left m. menu" << endl;
                    cin >> move;
                }
            }
            else
            {
                // space sickness
                player.setHealth(player.getHealth() - (player.getHealth() * .3));
                cout << "Oh no! You have space sickness. Your health decreased by 30%." << endl;
                if(player.getHealth() == 0)
                {
                    return;
                }
                else
                {
                    cout << "Select one: w. up s. down d. right a. left m. menu" << endl;
                    cin >> move;
                }
            }
        }
        if(map.isNPCLocation())
        {

        }
        if(map.isSiteLocation())
        {
            cout << "Good job, you have found a site that may have some useful information about this planet. If you get this question right, the information will be revealed. If you answer incorrectly though, you’ll become more frustrated and lose 1% health due to stress." << endl;
            site();
            mainMenu();
        }
    }
    mainMenu();
}

// View Status
void viewStatus()
{
    string underscore = "_";
   cout << endl;
    cout << "Health" << endl;
    if(player.getHealth() % 5 != 0)
    {
        for(int i = 0; i < (player.getHealth() / 5) + 1; i++)
        {
            cout << underscore;
        }
        cout << " " << player.getHealth() << "%" << endl;
        cout << endl;
    }
    if(player.getHealth() % 5 == 0)
    {
        for(int i = 0; i < (player.getHealth() / 5); i++)
        {
            cout << underscore;
        }
        cout << " " << player.getHealth() << "%" << endl;
        cout << endl;
    }
    cout << "Space Suit Health" << endl;
    // cout << player.getSpaceSuitHealth() << endl;
    if(player.getSpaceSuitHealth() % 5 != 0)
    {
        for(int i = 0; i < (player.getSpaceSuitHealth() / 5) + 1; i++)
        {
            cout << underscore;
        }
        cout << " " << player.getSpaceSuitHealth() << "%" << endl;
        cout << endl;
    }
    if(player.getSpaceSuitHealth() % 5 == 0)
    {
        for(int i = 0; i < (player.getSpaceSuitHealth() / 5); i++)
        {
            cout << underscore;
        }
        cout << " " << player.getSpaceSuitHealth() << "%" << endl;
        cout << endl;
    }
    cout << "Fuel Tank" << endl;
    int fuelTank = (player.getFuel() / 400000.0) * 100;
    // cout << fuelTank << endl;
    if(fuelTank % 5 != 0)
    {
        for(int i = 0; i < (fuelTank / 5) + 1; i++)
        {
            cout << underscore;
        }
        cout << " " << fuelTank << "%" << endl;
        cout << endl;
    }
    if(fuelTank % 5 == 0)
    {
        for(int i = 0; i < (fuelTank / 5); i++)
        {
            cout << underscore;
        }
        cout << " " << fuelTank << "%" << endl;
        cout << endl;
    }

    cout << "--------------------------------------------------" << endl;
    cout << endl;

    // fix planet
    cout << "Planets explored: " << planetNum << endl;
    cout << "Planets accurately reported habitable: " << habitablePlanets << endl;
    cout << "Planets inaccurately reported habitable: " << planetsGuessed - habitablePlanets << endl;
    cout << endl;

    cout << "--------------------------------------------------" << endl;

    // Humans perished
    cout << endl;
    cout << "Humans saved (in millions): " << game.getHumansSaved() << endl;
    cout << "Humans perished (in millions): " << game.getHumansPerished() << endl;
    cout << endl;

    cout << "--------------------------------------------------" << endl;

    int lightsaber = 0;
    int blaster = 0;
    int beamGun = 0;
    // cout << player.getWeaponNum() << endl;
    // cout << player.getWeapon(1) << endl;
    for(int i = 0; i < player.getWeaponNum(); i++)
    {
        // cout << player.getWeapon(i) << endl;
        if(player.getWeapon(i) == "Light saber")
        {
            lightsaber++;
        }
        else if(player.getWeapon(i) == "Blaster")
        {
            blaster++;
        }
        else
        {
            beamGun++;
        }
    }

    cout << endl;
    cout <<  "- Money - $" << player.getMoney() << endl;
    cout << "- WEAPONS - " << player.getWeaponNum() << endl;
    cout << "1. Light Saber - "<< lightsaber << endl;
    cout << "2. Blaster - " <<  blaster << endl;
    cout << "3. Beam gun - " << beamGun << endl;
    cout << "- TRANSLATOR - " << player.getTranslator() << endl;
    cout << "- SPACE SUIT GRADE #" << player.getSpaceSuit() << endl;
    cout << "- MEDICAL KITS - " << player.getMedicalKit() << endl;
    cout << "- FUEL - " << player.getFuel() << " Gallons" << endl;
    cout << endl;

    mainMenu();
}

// Report as habitable
void habitable()
{
    cout << "Are you sure you want to report back to mission control that this planet is habitable? As a reminder, here is your log book:" << endl;
    logBook();
    return;
    cout << "Reporting this planet is irreversible." << endl;
    cout << endl;
    cout << "Ready to report? [y/n]" << endl;
    char choice;
    cout << "Are you sure you want to enter this wormhole? You will start a new page in your log book and you will lose fuel.\nEnter wormhole? [y/n]" << endl;
    cin >> choice;
    if(choice != 'y' && choice != 'n')
    {
        cout << "Re-enter a valid input." << endl;
        cin >> choice;
    }
    if(choice == 'y')
    {
        if(map.isHabitable() == 1)
        {
            cout << "Congratulations! You have saved people! Planet " << planet.getFirstString() << "-" << planet.getSecondString() << " is their new home." << endl;
            map.resetMap();
            planetNum++;
            newPlanet();
            mainMenu();
        }
        else
        {
            cout << "Your decision has left to tragedy. Keep exploring." << endl;
            map.resetMap();
            planetNum++;
            newPlanet();
            mainMenu();
        }
    }
    if(choice == 'n')
    {
        mainMenu();
    }
}

// Main menu
void mainMenu()
{
    int choice = 0;

    // Map
    int siteNum = 0;
    int col = 0;
    int row = 0;
    int type = 0;
    int misfortuneNum = 0;

    srand(time(0));
    siteNum = (rand() % 10) + 1;
    misfortuneNum = (rand() % 10) + 1;
    // cout << siteNum << endl;

    for(int i = 0; i < siteNum; i++)
    {
        col = rand() % 10;
        row = rand() % 10;
        type = rand() % 10;
        map.spawnSite(row,col,type);
    }

    for(int i = 0; i < misfortuneNum; i++)
    {
        col = rand() % 10;
        row = rand() % 10;
        type = rand() % 10;
        map.spawnMisfortune(row,col,type);
    }

    int alienRow = (rand() % 10) + 1;
    int alienCol = (rand() % 10) + 1;
    map.spawnNPC(alienRow,alienCol);

    map.displayMap();

    // Menu
    cout << "Select one:" << endl;
    cout << "1. Move" << endl;
    cout << "2. View status" << endl;
    cout << "3. View log book" << endl;
    cout << "4. Resource Center" << endl;
    cout << "5. Report planet as habitable" << endl;
    cout << "6. Enter wormhole to next planet" << endl;
    cout << "7. Give up" << endl;
    cin >> choice;

    if(choice < 1 || choice > 7)
    {
        cout << "Re-enter a valid option." << endl;
        cin >> choice;
    }
    if(choice == 1)
    {
        mapChoice();
    }
    else if(choice == 2)
    {
        viewStatus();
    }
    else if(choice == 3)
    {
        logBook();
        mainMenu();
    }
    else if(choice == 4)
    {
        resourceCenter();
        mainMenu();
    }
    else if(choice == 5)
    {
        habitable();
        mainMenu();
    }
    else if(choice == 6)
    {
        char choice;
        cout << "Are you sure you want to enter this wormhole? You will start a new page in your log book and you will lose fuel.\nEnter wormhole? [y/n]" << endl;
        cin >> choice;
        if(choice != 'y' && choice != 'n')
        {
            cout << "Re-enter a valid input." << endl;
            cin >> choice;
        }
        if(choice == 'y')
        {
            map.resetMap();
            planetNum++;
            newPlanet();
            mainMenu();
        }
        if(choice == 'n')
        {
            mainMenu();
        }
    }
    else if(choice == 7)
    {
        char yesNo;
        cout << "Are you sure you want to give up? [y/n]" << endl;
        cin >> yesNo;
        if(yesNo != 'y' && yesNo != 'n')
        {
            cout << "Re-enter a valid input." << endl;
            cin >> yesNo;
        }
        if(yesNo == 'y')
        {
            return;
        }
        if(yesNo == 'n')
        {
            mainMenu();
        }
    }
}

// Main functions
int main()
{
    // Phase 1
    string name = "";
    cout << "Please enter your name. You will be the astronaut exploring space!" << endl;
    cin >> name;
    player.setNamePlayer(name);

    // Choose crewmates
    chooseCrewmates();

    cout << endl;
    cout << "You have 200 000 Gallons of fuel and a default space suit to start with." << endl;
    cout << endl;

    // Go to resource center menu
    ifstream myFile;
    char enter;
    myFile.open("resource_center_info.txt");
    if(myFile.is_open())
    {
        string line;
        while(getline(myFile,line))
        {
            cout << line << endl;
        }
    }
    myFile.close();
    // char enter;
    cin.ignore();
    cout << "Hit enter when you have understood." << endl;
    cin.get();

    resourceCenter();

    // Board space shuttle
    cout << endl;
    cout << "Great purchase, Elon is sending a Cybertruck with your supplies to you right now." << endl;
    cin.ignore();
    cout << "Hit enter when you are ready to enter space and go to your first planet." << endl;
    cin.get();
    cout << "3,2,1 . . . LIFTOFF! You are now in space. Hit enter to start exploring your first planet." << endl;

    // Phase 2
    newPlanet();
    mainMenu();

    // End game
    if(player.getHealth() == 0)
    {
        cout << "You have died due to health loss. Had you planned better with more sophisticated materials, you may have been able to prevent this. You can no longer explore more of space." << endl;
    }
    else
    {
        cout << "All of humanity has left Earth! Your mission is over." << endl;
    }

    ifstream myFile2;
    myFile2.open("logBook.txt");
    if(myFile2.is_open())
    {
        string line;
        while(getline(myFile2,line))
        {
            cout << line << endl;
        }
    }
    myFile2.close();

    cout << "Here is a summary of how you did:" << endl;
    cout << "Planets explored: " << planetNum << endl;
    cout << "Play again to see if you can do better!" << endl;

    return 0;
}