------------------------
HOW TO COMPILE AND RUN
------------------------
Compile: g++ -std=c++17 g++ Player.cpp Crewmate.cpp Alien.cpp Planet.cpp Game.cpp Map.cpp gameDriver.cpp
Run: ./a.out
------------------------
DEPENDENCIES
------------------------
Player.h, Crewmate.h, Alien.h, Planet.h, Game.h, and Map.h must be in the same directory as the cpp 
files in order to compile.
------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Spring 2022 Project 3
Author: Sophia Montie
Recitation: 105 - Tiffany Pan
Date: April 21, 2022