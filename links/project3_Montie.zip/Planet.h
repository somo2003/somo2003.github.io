// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - Planet.h file

#ifndef PLANET_H
#define PLANET_H

#include<iostream>

using namespace std;

class Planet
{
    public:
        Planet();
        Planet(string,string,double,double);

        string getFirstString();
        string getSecondString();
        double getPlanetSize();
        double getFueldForPlanet();
        bool getHability();
        double getNewPlanetCapac();

        void setFirstString();
        void setSecondString();
        void setPlanetSize();
        void setFuelForPlanet(double newFuelForPlanet);
        void setHability(bool newHability);
        void setPlanetCapac();

    private:
        string firstString;
        string secondString;
        double planetSize;
        double fuelForPlanet;
        bool hability;
        double planetCapac;
};

#endif