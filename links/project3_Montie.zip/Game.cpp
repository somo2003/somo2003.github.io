// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - Game.cpp file

#include "Player.h"
#include "Crewmate.h"
#include "Alien.h"
#include "Map.h"
#include "Game.h"

#include<iostream>
#include <fstream>

using namespace std;

int split2(string inputString, char separator,string arr[],int size)
{
    int count = 0;
    int arrCount = 0;
    string empty = "";
    string word = "";
    bool check = true;
    if(inputString == "")
    {
        count = 0;
    }
    while (size > 0)
    {
        for (int i = 0; i < inputString.length() && check == true; i++)
        {
            char separatorChar = inputString[i];
            if (separatorChar == separator)
            {
                if(word.length() != 0)
                {
                    arr[arrCount] = word; 
                    count++;
                    arrCount++;
                }
                word = "";
                if (count == size)
                {
                    check = false;
                }
            }
            if(separatorChar != separator)
            {
                word = word + inputString[i];
            }
            if(i == inputString.length() - 1)
            {
                arr[arrCount] = word;
                count++;
                arrCount++;
            }
        }
        if(inputString == empty)
        {
            return 0;
        }
        if(check == false)
        {
            return -1;
        }
        if(arrCount == 0)
        {
            arr[arrCount] = inputString;
            return 1;
        }
        size--;
        break;
    }

    return count;

}

Game::Game()
{
    numPlayers = 0;
    numCrewmates = 0;
    numAliens = 0;
    numPlanets = 0;

    humansPerished = 0;
    humansSaved = 0;
}

Game::Game(int newHumansPerished,int newHumansSaved)
{
    humansPerished = newHumansPerished;
    humansSaved = newHumansSaved;
}

int Game::getSizePlayer()
{
    return SIZE_PLAYER;
}

int Game::getSizeCrewmate()
{
    return SIZE_CREWMATE;
}

int Game::getSizeAlien()
{
    return SIZE_ALIEN;
}

int Game::getNumPlayers()
{
    return numPlayers;
}

int Game::getNumCrewmates()
{
    return numCrewmates;
}

int Game::getNumAliens()
{
    return numAliens;
}

// int Game::readAlienConversation(string filename)
// {
//     // will read from aliens_conversations.txt
//     // will assign if habitable or not
// }

// int Game::readPlanetName(string filename)
// {
//     // will read from four_letter_words
//     // will assign name to planet
// }

void Game::readQuestions(string filename)
{
    string arr1[2];
    string arr2[4];
    vector<string> allLines;
    // vector<string> answers;

    int fileSize = 0;

    ifstream myFile;
    myFile.open(filename);
    if(myFile.is_open())
    {
        string line;
        while(getline(myFile,line))
        {
            allLines.push_back(line);
            fileSize++;
            // answers.push_back(arr2[1]);
        }

        srand(time(0));
        int rand1 = (rand() % fileSize);
        // cout << rand1 << endl;
        split2(allLines.at(rand1),';',arr1,2); 
        split2(arr1[1],',',arr2,4);

        cout << arr1[0] << endl;
        // cout << arr1[1] << endl;
        cout << "a. " << arr2[0] << endl;
        cout << "b. " << arr2[1] << endl;
        cout << "c. " << arr2[2] << endl;
        cout << "d. " << arr2[3] << endl;

        //cout << fileSize << endl;
    }
    myFile.close();

    return;
}

// int Game::readAlienNames(string filename)
// {
//     // will read alien_names.txt 
//     // will assign alien name
// }

int Game::getHumansSaved()
{
    return humansSaved;
}

int Game::getHumansPerished()
{
    return humansPerished;
}

void Game::setHumansSaved(int newHumansSaved)
{
    humansSaved = newHumansSaved;
}

void Game::setHumansPerished(int newHumansPerished)
{
    humansPerished = newHumansPerished;
}

void Game::setNumPlanets(int NewNumPlanets)
{
    numPlanets = NewNumPlanets;
}

int Game::getNumPlanets()
{
    return numPlanets;
}