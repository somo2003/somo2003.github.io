// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - Player.h file

#ifndef PLAYER_H
#define PLAYER_H

#include<iostream>
#include<vector>

using namespace std;

class Player
{
    public:
        Player();
        Player(string,string[],int,int,int,int,bool,int,vector<string>,int);

        string getNamePlayer();
        string getCrewmates(int index);
        int getCrewSize();
        int getMoney(); 
        int getSpaceSuit();
        int getWeaponSize();
        string getWeapon(int index);
        int getWeaponNum();
        int getMedicalKit();
        int getHealth();
        int getFuel();
        bool getTranslator();
        int getSpaceSuitHealth();

        void setNamePlayer(string newNamePlayer);
        void chooseCrewmates(string newCrewmate,int index);
        void readCrewmatesFile(string filename);
        void setMoney(int newMoney);  
        void setSpaceSuit(int newSpaceSuit); 
        void setWeapon(string newWeapon);
        void setWeaponNum(int newWeaponNum);
        void setHealth(int newHealth);
        void setMedicalKit(int newMedicalKit);
        void setFuel(int newFuel);
        void setTranslator(bool newTranslator);
        void setSpaceSuitHealth(int newSpaceSuitHealth);
        void eraseWeapon(int index);

    private:
        string namePlayer;
        static const int CREW_SIZE = 2;
        string crewmates[CREW_SIZE];
        int money;
        int spaceSuit;
        static const int WEAPON_SIZE = 2;
        int weaponNum;
        vector<string> weapon;
        int health;
        int medicalKit;
        int fuel;
        bool translator;
        int spaceSuitHealth;
};

#endif