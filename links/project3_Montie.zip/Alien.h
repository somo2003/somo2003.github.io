// CSCI1300 Spring 2022
// Author: Sophia Montie
// Recitation: 105 -Tiffany Phan
// Project 3 - Alien.h file

#ifndef ALIEN_H
#define ALIEN_H

#include<iostream>

using namespace std;

class Alien
{
    public:
        Alien();
        Alien(string,bool);

        string getNameAlien();
        bool getHostility();

        void setNameAlien(string newNameAlien);
        void setHostility(bool newHostility);
        void readAlienNames();

    private:
        string nameAlien;
        bool hostility;
};

#endif